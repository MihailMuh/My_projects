import traceback
from scriptspy.error import error_output
import pygame
try:
    from scriptspy import game_preview
    game_preview.preview()
except (IOError, ImportError, IndexError, KeyError, NameError, SyntaxError, OSError, TypeError,
        ValueError, AttributeError):
    pygame.display.set_mode((100, 100))
    error_output(traceback.format_exc())
