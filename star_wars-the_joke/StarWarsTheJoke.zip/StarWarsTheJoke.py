from scriptspy import game_preview

game_preview.preview()
