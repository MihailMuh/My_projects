import traceback
from scriptspy import error
import pygame
try:
    from scriptspy import game_preview
    game_preview.preview()
except (IOError, ImportError, IndexError, KeyError, NameError, SyntaxError, OSError, TypeError, ValueError):
    pygame.display.set_mode((100, 100))
    error.error_output(traceback.format_exc())
